from django.shortcuts import render
from joblib import load
from django.http import HttpResponse
import xgboost as xgb

# Load your pre-trained model
model = load('./savedModels/model.joblib')


def predictor(request):
    return render(request , 'main.html')



def fromInfo(request):
    # Retrieve the values from the POST request
    dropoff_latitude = request.POST.get('dropoff_latitude')
    year = request.POST.get('year')
    ewr_dist = request.POST.get('ewr_dist')
    lga_dist = request.POST.get('lga_dist')
    nyc_dist = request.POST.get('nyc_dist')
    distance = request.POST.get('distance')
    bearing = request.POST.get('bearing')

    # Check if all required parameters are present
    if None in [dropoff_latitude, year, ewr_dist, lga_dist, nyc_dist, distance, bearing]:
        return HttpResponse("Error: Missing one or more form fields")

    # Convert input data to appropriate types
    try:
        dropoff_latitude = float(dropoff_latitude)
        year = int(year)
        ewr_dist = float(ewr_dist)
        lga_dist = float(lga_dist)
        nyc_dist = float(nyc_dist)
        distance = float(distance)
        bearing = float(bearing)
    except ValueError:
        return HttpResponse("Error: Invalid input data")

    # Create a DMatrix object from the data
    data = xgb.DMatrix([[dropoff_latitude, year, ewr_dist, lga_dist, nyc_dist, distance, bearing]])

   # Print the data to check its format
    print("Data for prediction:", data)

    # Predict using the model
    y_pred = model.predict(data)

    # Print the prediction result
    print("Prediction result:", y_pred)

    # Format the result
    result = f"${y_pred[0]:.2f}"

    # Pass the result to the 'result.html' template
    return render(request, 'result.html', {'result': result})